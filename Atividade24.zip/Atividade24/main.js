function dividir(a, b) {
    var resultado = a / b;
    if (isNaN(resultado)) {
        console.log("Divisão deu NaN");
    } else if (!isFinite(resultado)) {
        console.log("Divisão deu Infinity");
    } else {
        return resultado;
    }
}

console.log(dividir(1, 2));      
console.log(dividir(1, 0));      
console.log(dividir(0, 0));      
console.log(dividir(1, Infinity)); 