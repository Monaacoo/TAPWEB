function transformText(){
    const text = document.getElementById("text").value
    const lower = document.getElementById("lower")
    const upper = document.getElementById("upper")
    const output = document.getElementById("output")

    let transformText = text

    if (lower.checked){
        transformText = transformText.toLowerCase()
    }
    if (upper.checked){
        transformText = transformText.toUpperCase()
    }

    output.textContent = transformText
}