var num1
var num2

num1 = prompt ("coloque um numero")
num2 = prompt ("coloque outro numero")

var soma = parseFloat(num1) + parseFloat(num2)
var sub = num1 - num2
var nums = "numero 1 = " + num1 +  " \n numero 2 = " + num2
var divi = num1 / num2
var resto = num1 % num2

alert("resultado da soma =" + soma + " \n resultado subtração = " + sub + " \n resultado dos produtos = " + nums + " \n resultado da divisão = " + divi +" \n resultado do resto = " + resto)
