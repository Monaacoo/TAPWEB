var nota1 
var nota2
var nota3

nota1 = prompt("Qual sua nota?")
nota2 = prompt("Qual sua nota?")
nota3 = prompt("Qual sua nota?")

var media = (parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3

alert(media)


