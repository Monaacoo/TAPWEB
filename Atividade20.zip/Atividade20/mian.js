//questao 1
const objLivro1 = {
    titulo: "Dom Casmurro",
    autor: "Machado de Assis"
}

alert(objLivro1.titulo + "" + objLivro.autor)
alert(`${objLivro1.titulo} ${objLivro.autor}`)
alert(JSON.stringify(objLivro1))

var objLivro2 = {}
objLivro2.titulo = "Dom Casmurro"
objLivro2.autor = "Machado de Assis"

var ObjLivro3 = new Object()
ObjLivro3.titulo = "Dom Casmurro"
ObjLivro3.autor = "Machado de Assis"

function Livro(_Titulo, _Autor){
    this.titulo = _Titulo
    this.autor = _Autor
}
var objLivro4 = new Livro('Dom Casmurro', "Machado de Assis")

class Livro1{
    constructor(titulo, autor){
    this.titulo = titulo
    this.autor = autor
    }
}
const objLivro5 = new Livro1("Titulo do livro", "Autor do Livro")

//questao 5
function Ordena(n1,n2,n3){
    var matriz = [n1, n2, n3]
    matriz.sort(function(a,b){b-a})
    return matriz
}
alert(Ordena(5,2,2))

function Ordena2(n1,n2,n3){
    var matriz = [n1,n2,n3]
    matriz.sort(function(a,b){a-b})
    matriz.reverse()
    return matriz
}
alert(Ordena2(5,2,2))

function Ordena3(n1,n2,n3){
    let maior = Math.max(n1,n2,n3)
    let menor = Math.min(n1,n2,n3)
    let meio
    if(n1 !== maior && n1 !== menor){
        meio = n1
    }else if(n2 !== maior && n2 !== menor){
        meio = n2
    }else{
        meio = n3
    }
    return `${maior} ${meio} ${menor}`
}
alert(Ordena3(10,5,8))

//questao 6
alert(objeto.codigo + "" + objeto.descricao)

//questao 9
var entrada = 1 + 2 + "3" + 4
var saida = ""
for(var i = 0; i < 5; i++){
    saida += entrada + i + ""
}
alert (saida)

