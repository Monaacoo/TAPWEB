var altura = parseFloat(prompt("informe sua altura"))
var peso = parseFloat(prompt("informe seu peso"))

var imc = peso / (altura * altura)

function ClassificacaoIMC(imc){
    if (imc < 10.5){
    return "Magreza"
    } else if (imc >= 18.5 && imc < 25){
        return "Normal"
    }else if (imc >= 25 && imc < 30){
        return "Sobrepeso"
    }else if ( imc >= 30 && imc < 40){
        return "Obesidade"
    }else{
        return "Obsidade Grave"
    }
}

function Grau(imc){
    if (imc < 18.5 || imc >= 40){
        return 0
    }else if (imc >= 18.5 && imc < 25){
        return 0
    }
    else if (imc >= 25 && imc < 30){
        return 1
    }
    else if (imc >= 30 && imc < 40){
        return 2
    }
    else {
        return 3
    }
}
ClassificacaoIMC()
Grau()
const classificacao = ClassificacaoIMC(imc)
const grauObesidadae = Grau(imc)

alert("imc: " + imc.toFixed(2)) //ou colocar Math.round(imc,1)
alert("Classificacao: " + classificacao)
alert("Grau: " + grauObesidadae)


