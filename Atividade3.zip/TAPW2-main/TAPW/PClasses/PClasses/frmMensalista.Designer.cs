﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.a = new System.Windows.Forms.Label();
            this.d = new System.Windows.Forms.Label();
            this.c = new System.Windows.Forms.Label();
            this.b = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.btnInstaciar1 = new System.Windows.Forms.Button();
            this.btnInstaciar2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(240, 64);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(244, 26);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(240, 210);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(244, 26);
            this.txtData.TabIndex = 1;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(240, 153);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(244, 26);
            this.txtSalario.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(240, 105);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(244, 26);
            this.txtNome.TabIndex = 3;
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.Location = new System.Drawing.Point(39, 70);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(73, 20);
            this.a.TabIndex = 4;
            this.a.Text = "Matricula";
            // 
            // d
            // 
            this.d.AutoSize = true;
            this.d.Location = new System.Drawing.Point(39, 213);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(195, 20);
            this.d.TabIndex = 5;
            this.d.Text = "Data Entrada na Empresa";
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.Location = new System.Drawing.Point(39, 159);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(113, 20);
            this.c.TabIndex = 6;
            this.c.Text = "Salario Mensal";
            // 
            // b
            // 
            this.b.AutoSize = true;
            this.b.Location = new System.Drawing.Point(39, 111);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(51, 20);
            this.b.TabIndex = 7;
            this.b.Text = "Nome";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.rbtnNao);
            this.groupBox1.Controls.Add(this.rbtnSim);
            this.groupBox1.Location = new System.Drawing.Point(595, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 172);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trabalha em Home Office";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(29, 85);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(63, 24);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "SIM";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(29, 115);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(68, 24);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "NAO";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // btnInstaciar1
            // 
            this.btnInstaciar1.Location = new System.Drawing.Point(70, 287);
            this.btnInstaciar1.Name = "btnInstaciar1";
            this.btnInstaciar1.Size = new System.Drawing.Size(190, 105);
            this.btnInstaciar1.TabIndex = 9;
            this.btnInstaciar1.Text = "Instanciar Mensalidade";
            this.btnInstaciar1.UseVisualStyleBackColor = true;
            this.btnInstaciar1.Click += new System.EventHandler(this.BtnInstaciar1_Click);
            // 
            // btnInstaciar2
            // 
            this.btnInstaciar2.Location = new System.Drawing.Point(429, 287);
            this.btnInstaciar2.Name = "btnInstaciar2";
            this.btnInstaciar2.Size = new System.Drawing.Size(190, 106);
            this.btnInstaciar2.TabIndex = 10;
            this.btnInstaciar2.Text = "Instanciar Mensalidade passando parâmetros";
            this.btnInstaciar2.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 490);
            this.Controls.Add(this.btnInstaciar2);
            this.Controls.Add(this.btnInstaciar1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.b);
            this.Controls.Add(this.c);
            this.Controls.Add(this.d);
            this.Controls.Add(this.a);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.Label d;
        private System.Windows.Forms.Label c;
        private System.Windows.Forms.Label b;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Button btnInstaciar1;
        private System.Windows.Forms.Button btnInstaciar2;
    }
}