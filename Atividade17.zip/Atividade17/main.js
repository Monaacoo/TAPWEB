function validarFormulario(form){
    if (form.nome.value.length < 10){
        alert ("o campo 'nome' deve ter no minimo 10 caracteries")
        return false
    }

    if (form.email.value.indexOf('@') === -1){
        alert("o campo deve conter @")
        return false
    }
    if (form.comenario.value.length < 20){
        alert ("o comentario deve ter no minimo 20 caracteries")
        return false
    }
    let radios = form.opcao
    let radioSelect = false

    for (let i = 0; i < radios.length; i++){
        if (radios[i].checked){
            radioSelect = true
            break
        }
    if(!radioSelect){
        alert("voce deve selecionar uma opção")
        return false
    }
    if(form.pesquisa.value === ""){
        alert("voce deve preencher o campo 'Pesquisa'")
        return false
    }
    return true
    }
}