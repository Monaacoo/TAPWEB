//Atividade Retangulo
function calcularArea() {
    function Retangulo(x, y) {
        this.x = x
        this.y = y
        var resultado

        this.Calcular = function () {
            resultado = this.x * this.y
            return resultado
        }
    }

    var base = prompt("Digite a base do retangulo: ")
    var altura = prompt("Digite a altura do retangulo: ")
    varcalculo = new Retangulo(base, altura)
    alert(varcalculo.Calcular())
}

//Atividade Conta
function mostrarDados() {
    function Conta() {
        var nome_correntista
        var banco
        var num_conta
        var saldo
        this.setNome_Correntista = function (value) {
            this.nome_correntista = value
        }
        this.getNome_Correntista = function () {
            return this.nome_correntista
        }
        this.setBanco = function (value) {
            this.banco = value
        }
        this.getBanco = function () {
            return this.banco
        }
        this.setNum_Conta = function (value) {
            this.num_conta = value
        }
        this.getNum_Conta = function () {
            return this.num_conta;
        }
        this.setSaldo = function (value) {
            this.saldo = value
        }
        this.getSaldo = function () {
            return this.saldo
        }
    }

    function Corrente() {
        Conta.call(this)
        var saldoEspecial

        this.setSaldoEspecial = function (value) {
            saldoEspecial = value
        }

        this.getSaldoEspecial = function () {
            return saldoEspecial
        }
    }

    Corrente.prototype = Object.create(Conta.prototype)

    function Poupanca() {
        Conta.call(this)

        var juros, dataVencimento

        this.setJuros = function (value) {
            juros = value
        }

        this.getJuros = function () {
            return juros
        }

        this.setDataVencimento = function (value) {
            dataVencimento = value
        }

        this.getDataVencimento = function () {
            return dataVencimento
        }
    }

    Poupanca.prototype = Object.create(Conta.prototype)

    var objContaCorrente = new Corrente()
    objContaCorrente.setNome_Correntista('Lucas')
    objContaCorrente.setBanco('Itau')
    objContaCorrente.setNum_Conta('123456')
    objContaCorrente.setSaldo(100000)
    objContaCorrente.setSaldoEspecial(50000)

    var objContaPoupanca = new Poupanca()
    objContaPoupanca.setNome_Correntista('Lucas1')
    objContaPoupanca.setBanco('Inter')
    objContaPoupanca.setNum_Conta('654321')
    objContaPoupanca.setSaldo(300000)
    objContaPoupanca.setJuros(0.01)
    objContaPoupanca.setDataVencimento('21/10/2023')

  alert("Conta corrente: " + objContaCorrente.getNome_Correntista() + "\n" + "Banco: " + objContaCorrente.getBanco() + "\n" + "Numero da conta: " + objContaCorrente.getNum_Conta() + "\n" + "Seu saldo: " + objContaCorrente.getSaldo() + "\n" + "Seu saldo especial: " + objContaCorrente.getSaldoEspecial())
  alert("Conta poupança: " + objContaPoupanca.getNome_Correntista() + "\n" + "Seu banco: " + objContaPoupanca.getBanco() + "\n" + "Numero da conta poupança: " + objContaPoupanca.getNum_Conta() + "\n" + "Seu saldo: " + objContaPoupanca.getSaldo() + "\n" + "Juros: " + objContaPoupanca.getJuros() + "\n" + "Data de Vencimento: " + objContaPoupanca.getDataVencimento())
}