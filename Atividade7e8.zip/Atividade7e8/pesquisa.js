var somaIdade = 0;
var idadeVelha = -1;
var idadeNova = 999;
var countPessimo = 0;
var countBom = 0;
var countMulheres = 0;
var countHomen = 0;

var numeroPessoas = parseInt(prompt("Quantas pessoas responderam ao questionário?"));

for (var i = 0; i < numeroPessoas; i++) {
    var idade = parseInt(prompt("Informe a idade da pessoa " + (i + 1)));
    var sexo = prompt("Informe o sexo da pessoa " + (i + 1) + " (M/F)").toUpperCase();
    var opiniao = parseInt(prompt("Informe a opinião da pessoa " + (i + 1) + " (Ótimo=4, Bom=3, Regular=2, Péssimo=1)"));

    somaIdade += idade;

    if (idade > idadeVelha) {
        idadeVelha = idade;
    }
    if (idade < idadeNova) {
        idadeNova = idade;
    }

    if (opiniao === 1) {
       countPessimo++;
    }

    if (opiniao === 3 || opiniao === 4) {
        countBom++;
    }

    if (sexo === 'F') {
        countMulheres++;
    } else if (sexo === 'M') {
        countHomen++;
    }
}

var mediaIdade = somaIdade / numeroPessoas;
var countBom = (countBom / numeroPessoas) * 100;

alert('Média das idades: ' + mediaIdade);
alert('Idade da pessoa mais velha: ' + idadeVelha);
alert('Idade da pessoa mais nova: ' + idadeNova);
alert('Quantidade de pessoas que responderam péssimo: ' + countPessimo);
alert('Porcentagem de pessoas que responderam ótimo e bom: ' + countBom + '%');
alert('Número de mulheres que responderam ao questionário: ' + countMulheres);
alert('Número de homens que responderam ao questionário: ' + countHomen);