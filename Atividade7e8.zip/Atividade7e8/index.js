function jogar(){
    var opcoes= ["pedra", "papel", "tesoura"]
    var escolhaUsuario= prompt("escolha: pedra, papel ou tesoura").toLowerCase()
    var escolhaMaquina = opcoes[Math.floor(Math.random() * 3)]

    alert ("Voce escolheu: " + escolhaUsuario)
    alert ("Maquina escolheu: " + escolhaMaquina)

    if (escolhaUsuario === escolhaMaquina){
        alert("Empate")
    } else if (
        (escolhaUsuario === "pedra" && escolhaMaquina === "tesoura") ||
        (escolhaUsuario === "papel" && escolhaMaquina === "pedra") ||
        (escolhaUsuario === "tesoura" && escolhaUsuario === "papel")
    ){
        alert ("voce ganhou")
    }    else {
            alert ("maquina ganhou")
        }
    }
    jogar()
